import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Animated } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { 
  Cpu, 
  Zap, 
  Shield, 
  Users, 
  TrendingUp, 
  Globe,
  Activity,
  ChevronRight
} from 'lucide-react-native';

export default function CommandCenter() {
  const insets = useSafeAreaInsets();
  const [aiStatus, setAiStatus] = useState('Evolving');
  const [resources, setResources] = useState({
    energy: 2847,
    data: 1523,
    nanobots: 456
  });

  const pulseAnim = new Animated.Value(1);

  useEffect(() => {
    const pulse = () => {
      Animated.sequence([
        Animated.timing(pulseAnim, {
          toValue: 1.1,
          duration: 1000,
          useNativeDriver: true,
        }),
        Animated.timing(pulseAnim, {
          toValue: 1,
          duration: 1000,
          useNativeDriver: true,
        }),
      ]).start(() => pulse());
    };
    pulse();
  }, []);

  const StatCard = ({ icon: Icon, title, value, color = '#00d4ff' }) => (
    <View style={{
      backgroundColor: '#1a1a1a',
      borderRadius: 12,
      padding: 16,
      flex: 1,
      marginHorizontal: 4,
      borderWidth: 1,
      borderColor: '#333',
    }}>
      <Icon color={color} size={24} style={{ marginBottom: 8 }} />
      <Text style={{ color: '#888', fontSize: 12, marginBottom: 4 }}>{title}</Text>
      <Text style={{ color: '#fff', fontSize: 18, fontWeight: 'bold' }}>{value}</Text>
    </View>
  );

  const ActionCard = ({ icon: Icon, title, subtitle, onPress, color = '#00d4ff' }) => (
    <TouchableOpacity
      onPress={onPress}
      style={{
        backgroundColor: '#1a1a1a',
        borderRadius: 12,
        padding: 16,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: '#333',
        flexDirection: 'row',
        alignItems: 'center',
      }}
    >
      <View style={{
        backgroundColor: color + '20',
        borderRadius: 8,
        padding: 8,
        marginRight: 12,
      }}>
        <Icon color={color} size={24} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ color: '#fff', fontSize: 16, fontWeight: '600', marginBottom: 2 }}>
          {title}
        </Text>
        <Text style={{ color: '#888', fontSize: 14 }}>{subtitle}</Text>
      </View>
      <ChevronRight color="#666" size={20} />
    </TouchableOpacity>
  );

  return (
    <View style={{ flex: 1, backgroundColor: '#0a0a0a' }}>
      <StatusBar style="light" />
      
      {/* Header */}
      <View style={{
        paddingTop: insets.top + 20,
        paddingHorizontal: 20,
        paddingBottom: 20,
        backgroundColor: '#111',
        borderBottomWidth: 1,
        borderBottomColor: '#333',
      }}>
        <Text style={{
          color: '#fff',
          fontSize: 28,
          fontWeight: 'bold',
          marginBottom: 8,
        }}>
          Command Center
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Animated.View style={{ transform: [{ scale: pulseAnim }] }}>
            <Activity color="#00ff88" size={16} />
          </Animated.View>
          <Text style={{ color: '#00ff88', fontSize: 14, marginLeft: 8 }}>
            AI Status: {aiStatus}
          </Text>
        </View>
      </View>

      <ScrollView 
        style={{ flex: 1 }} 
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Resource Stats */}
        <View style={{ padding: 20 }}>
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '600', marginBottom: 16 }}>
            Digital Resources
          </Text>
          <View style={{ flexDirection: 'row' }}>
            <StatCard 
              icon={Zap} 
              title="Energy" 
              value={resources.energy.toLocaleString()} 
              color="#ffaa00"
            />
            <StatCard 
              icon={Cpu} 
              title="Data" 
              value={resources.data.toLocaleString()} 
              color="#00d4ff"
            />
            <StatCard 
              icon={Shield} 
              title="Nanobots" 
              value={resources.nanobots.toLocaleString()} 
              color="#ff6b6b"
            />
          </View>
        </View>

        {/* Quick Actions */}
        <View style={{ paddingHorizontal: 20 }}>
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '600', marginBottom: 16 }}>
            Strategic Operations
          </Text>
          
          <ActionCard
            icon={Globe}
            title="Reconstruct Sector"
            subtitle="Rebuild damaged digital territories"
            color="#00ff88"
            onPress={() => {}}
          />
          
          <ActionCard
            icon={Users}
            title="Alliance Network"
            subtitle="Manage tactical partnerships"
            color="#8b5cf6"
            onPress={() => {}}
          />
          
          <ActionCard
            icon={Cpu}
            title="AI Evolution Lab"
            subtitle="Upgrade your digital civilization"
            color="#f59e0b"
            onPress={() => {}}
          />
          
          <ActionCard
            icon={TrendingUp}
            title="Smart City Systems"
            subtitle="Deploy Indian tech innovations"
            color="#06b6d4"
            onPress={() => {}}
          />
        </View>

        {/* World Status */}
        <View style={{ paddingHorizontal: 20, marginTop: 20 }}>
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '600', marginBottom: 16 }}>
            World Fragment Status
          </Text>
          <View style={{
            backgroundColor: '#1a1a1a',
            borderRadius: 12,
            padding: 16,
            borderWidth: 1,
            borderColor: '#333',
          }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 12 }}>
              <Text style={{ color: '#888', fontSize: 14 }}>Reconstruction Progress</Text>
              <Text style={{ color: '#00ff88', fontSize: 14, fontWeight: '600' }}>23.7%</Text>
            </View>
            <View style={{
              backgroundColor: '#333',
              height: 8,
              borderRadius: 4,
              overflow: 'hidden',
            }}>
              <View style={{
                backgroundColor: '#00ff88',
                height: '100%',
                width: '23.7%',
                borderRadius: 4,
              }} />
            </View>
            <Text style={{ color: '#666', fontSize: 12, marginTop: 8 }}>
              Next milestone: Sector 7 stabilization
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}