import React, { useState, useEffect } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Animated } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { 
  Cpu, 
  Zap, 
  Shield, 
  Brain,
  Cog,
  TrendingUp,
  Plus,
  ArrowUp,
  Star,
  Lock,
  CheckCircle
} from 'lucide-react-native';

export default function Evolution() {
  const insets = useSafeAreaInsets();
  const [selectedUnit, setSelectedUnit] = useState(null);
  const [evolutionPoints, setEvolutionPoints] = useState(2847);
  
  const glowAnim = new Animated.Value(1);

  useEffect(() => {
    const glow = () => {
      Animated.sequence([
        Animated.timing(glowAnim, {
          toValue: 1.3,
          duration: 2000,
          useNativeDriver: true,
        }),
        Animated.timing(glowAnim, {
          toValue: 1,
          duration: 2000,
          useNativeDriver: true,
        }),
      ]).start(() => glow());
    };
    glow();
  }, []);

  const units = [
    {
      id: 1,
      name: 'Neural Architect',
      level: 12,
      maxLevel: 25,
      type: 'AI Core',
      power: 2340,
      abilities: ['Smart City Design', 'Resource Optimization', 'Predictive Analytics'],
      upgradeCost: 450,
      color: '#00d4ff',
      icon: Brain,
      unlocked: true
    },
    {
      id: 2,
      name: 'Quantum Defender',
      level: 8,
      maxLevel: 20,
      type: 'Defense',
      power: 1890,
      abilities: ['Cyber Shield', 'Threat Detection', 'Auto-Repair'],
      upgradeCost: 320,
      color: '#00ff88',
      icon: Shield,
      unlocked: true
    },
    {
      id: 3,
      name: 'Data Harvester',
      level: 15,
      maxLevel: 30,
      type: 'Resource',
      power: 1560,
      abilities: ['Real-time Analytics', 'Pattern Recognition', 'Data Mining'],
      upgradeCost: 280,
      color: '#8b5cf6',
      icon: Cpu,
      unlocked: true
    },
    {
      id: 4,
      name: 'Nano Constructor',
      level: 0,
      maxLevel: 15,
      type: 'Builder',
      power: 0,
      abilities: ['Molecular Assembly', 'Self-Replication', 'Material Synthesis'],
      upgradeCost: 800,
      color: '#ffaa00',
      icon: Cog,
      unlocked: false
    }
  ];

  const aiTechnologies = [
    {
      id: 1,
      name: 'Adaptive Learning',
      description: 'AI systems learn from player behavior',
      level: 3,
      maxLevel: 5,
      cost: 600,
      unlocked: true,
      color: '#00d4ff'
    },
    {
      id: 2,
      name: 'Predictive Modeling',
      description: 'Forecast resource needs and threats',
      level: 2,
      maxLevel: 4,
      cost: 450,
      unlocked: true,
      color: '#8b5cf6'
    },
    {
      id: 3,
      name: 'Quantum Processing',
      description: 'Exponential computation power',
      level: 1,
      maxLevel: 3,
      cost: 1200,
      unlocked: true,
      color: '#00ff88'
    },
    {
      id: 4,
      name: 'Neural Networks',
      description: 'Advanced pattern recognition',
      level: 0,
      maxLevel: 6,
      cost: 800,
      unlocked: false,
      color: '#ff6b6b'
    }
  ];

  const UnitCard = ({ unit }) => {
    const IconComponent = unit.icon;
    const progressPercent = (unit.level / unit.maxLevel) * 100;
    
    return (
      <TouchableOpacity
        onPress={() => setSelectedUnit(unit)}
        style={{
          backgroundColor: '#1a1a1a',
          borderRadius: 12,
          padding: 16,
          marginBottom: 12,
          borderWidth: 1,
          borderColor: unit.unlocked ? unit.color + '40' : '#333',
          opacity: unit.unlocked ? 1 : 0.6,
        }}
      >
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
          <View style={{
            backgroundColor: unit.color + '20',
            borderRadius: 25,
            width: 50,
            height: 50,
            alignItems: 'center',
            justifyContent: 'center',
            marginRight: 12,
          }}>
            {unit.unlocked ? (
              <IconComponent color={unit.color} size={24} />
            ) : (
              <Lock color="#666" size={24} />
            )}
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: '#fff', fontSize: 16, fontWeight: 'bold', marginBottom: 2 }}>
              {unit.name}
            </Text>
            <Text style={{ color: unit.color, fontSize: 12 }}>
              {unit.type} • Level {unit.level}/{unit.maxLevel}
            </Text>
          </View>
          {unit.unlocked && (
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600' }}>
                {unit.power.toLocaleString()}
              </Text>
              <Text style={{ color: '#666', fontSize: 10 }}>Power</Text>
            </View>
          )}
        </View>
        
        {unit.unlocked && (
          <>
            <View style={{ marginBottom: 12 }}>
              <View style={{
                backgroundColor: '#333',
                height: 6,
                borderRadius: 3,
                overflow: 'hidden',
              }}>
                <View style={{
                  backgroundColor: unit.color,
                  height: '100%',
                  width: `${progressPercent}%`,
                  borderRadius: 3,
                }} />
              </View>
            </View>
            
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
              <View style={{ flex: 1 }}>
                <Text style={{ color: '#888', fontSize: 12, marginBottom: 4 }}>
                  Abilities:
                </Text>
                <Text style={{ color: '#666', fontSize: 10 }}>
                  {unit.abilities.slice(0, 2).join(', ')}
                </Text>
              </View>
              <TouchableOpacity style={{
                backgroundColor: unit.color + '20',
                borderRadius: 8,
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderWidth: 1,
                borderColor: unit.color,
                flexDirection: 'row',
                alignItems: 'center',
              }}>
                <ArrowUp color={unit.color} size={14} style={{ marginRight: 4 }} />
                <Text style={{ color: unit.color, fontSize: 12, fontWeight: '600' }}>
                  {unit.upgradeCost}
                </Text>
              </TouchableOpacity>
            </View>
          </>
        )}
        
        {!unit.unlocked && (
          <TouchableOpacity style={{
            backgroundColor: '#333',
            borderRadius: 8,
            padding: 12,
            alignItems: 'center',
            marginTop: 8,
          }}>
            <Text style={{ color: '#666', fontSize: 14, fontWeight: '600' }}>
              Unlock for {unit.upgradeCost} EP
            </Text>
          </TouchableOpacity>
        )}
      </TouchableOpacity>
    );
  };

  const TechCard = ({ tech }) => (
    <View style={{
      backgroundColor: '#1a1a1a',
      borderRadius: 12,
      padding: 16,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: tech.unlocked ? tech.color + '40' : '#333',
      opacity: tech.unlocked ? 1 : 0.6,
    }}>
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 8 }}>
        <Text style={{ color: '#fff', fontSize: 16, fontWeight: 'bold' }}>
          {tech.name}
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          {Array.from({ length: tech.maxLevel }).map((_, i) => (
            <Star
              key={i}
              color={i < tech.level ? tech.color : '#333'}
              size={16}
              fill={i < tech.level ? tech.color : 'transparent'}
              style={{ marginLeft: 2 }}
            />
          ))}
        </View>
      </View>
      
      <Text style={{ color: '#888', fontSize: 14, marginBottom: 12 }}>
        {tech.description}
      </Text>
      
      <View style={{ flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' }}>
        <Text style={{ color: tech.color, fontSize: 12 }}>
          Level {tech.level}/{tech.maxLevel}
        </Text>
        {tech.unlocked && tech.level < tech.maxLevel ? (
          <TouchableOpacity style={{
            backgroundColor: tech.color + '20',
            borderRadius: 8,
            paddingHorizontal: 12,
            paddingVertical: 6,
            borderWidth: 1,
            borderColor: tech.color,
          }}>
            <Text style={{ color: tech.color, fontSize: 12, fontWeight: '600' }}>
              Upgrade {tech.cost} EP
            </Text>
          </TouchableOpacity>
        ) : tech.level >= tech.maxLevel ? (
          <View style={{
            backgroundColor: '#00ff88' + '20',
            borderRadius: 8,
            paddingHorizontal: 12,
            paddingVertical: 6,
            flexDirection: 'row',
            alignItems: 'center',
          }}>
            <CheckCircle color="#00ff88" size={14} style={{ marginRight: 4 }} />
            <Text style={{ color: '#00ff88', fontSize: 12, fontWeight: '600' }}>
              Maxed
            </Text>
          </View>
        ) : (
          <TouchableOpacity style={{
            backgroundColor: '#333',
            borderRadius: 8,
            paddingHorizontal: 12,
            paddingVertical: 6,
          }}>
            <Text style={{ color: '#666', fontSize: 12, fontWeight: '600' }}>
              Unlock {tech.cost} EP
            </Text>
          </TouchableOpacity>
        )}
      </View>
    </View>
  );

  return (
    <View style={{ flex: 1, backgroundColor: '#0a0a0a' }}>
      <StatusBar style="light" />
      
      {/* Header */}
      <View style={{
        paddingTop: insets.top + 20,
        paddingHorizontal: 20,
        paddingBottom: 20,
        backgroundColor: '#111',
        borderBottomWidth: 1,
        borderBottomColor: '#333',
      }}>
        <Text style={{
          color: '#fff',
          fontSize: 28,
          fontWeight: 'bold',
          marginBottom: 8,
        }}>
          AI Evolution Lab
        </Text>
        <View style={{ flexDirection: 'row', alignItems: 'center' }}>
          <Animated.View style={{ transform: [{ scale: glowAnim }] }}>
            <Zap color="#00d4ff" size={16} />
          </Animated.View>
          <Text style={{ color: '#00d4ff', fontSize: 14, marginLeft: 8 }}>
            {evolutionPoints.toLocaleString()} Evolution Points
          </Text>
        </View>
      </View>

      <ScrollView 
        style={{ flex: 1 }} 
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* Digital Units */}
        <View style={{ padding: 20 }}>
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '600', marginBottom: 16 }}>
            Digital Units
          </Text>
          {units.map((unit) => (
            <UnitCard key={unit.id} unit={unit} />
          ))}
        </View>

        {/* AI Technologies */}
        <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '600', marginBottom: 16 }}>
            AI Technologies
          </Text>
          {aiTechnologies.map((tech) => (
            <TechCard key={tech.id} tech={tech} />
          ))}
        </View>

        {/* Evolution Stats */}
        <View style={{ paddingHorizontal: 20 }}>
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '600', marginBottom: 16 }}>
            Evolution Progress
          </Text>
          <View style={{
            backgroundColor: '#1a1a1a',
            borderRadius: 12,
            padding: 16,
            borderWidth: 1,
            borderColor: '#333',
          }}>
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 16 }}>
              <View style={{ alignItems: 'center' }}>
                <Brain color="#00d4ff" size={20} />
                <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600', marginTop: 4 }}>
                  47
                </Text>
                <Text style={{ color: '#666', fontSize: 10 }}>AI Level</Text>
              </View>
              <View style={{ alignItems: 'center' }}>
                <TrendingUp color="#00ff88" size={20} />
                <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600', marginTop: 4 }}>
                  +23%
                </Text>
                <Text style={{ color: '#666', fontSize: 10 }}>Efficiency</Text>
              </View>
              <View style={{ alignItems: 'center' }}>
                <Star color="#ffaa00" size={20} />
                <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600', marginTop: 4 }}>
                  12
                </Text>
                <Text style={{ color: '#666', fontSize: 10 }}>Innovations</Text>
              </View>
            </View>
            
            <View style={{ marginBottom: 12 }}>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
                <Text style={{ color: '#888', fontSize: 14 }}>Next Evolution Milestone</Text>
                <Text style={{ color: '#00d4ff', fontSize: 14, fontWeight: '600' }}>
                  Level 50
                </Text>
              </View>
              <View style={{
                backgroundColor: '#333',
                height: 8,
                borderRadius: 4,
                overflow: 'hidden',
              }}>
                <View style={{
                  backgroundColor: '#00d4ff',
                  height: '100%',
                  width: '94%',
                  borderRadius: 4,
                }} />
              </View>
            </View>
            
            <Text style={{ color: '#666', fontSize: 12, textAlign: 'center' }}>
              Unlock Quantum Consciousness at Level 50
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}