import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Switch } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { 
  Settings as SettingsIcon, 
  User, 
  Bell, 
  Shield, 
  Globe,
  Smartphone,
  Volume2,
  Moon,
  ChevronRight,
  LogOut,
  HelpCircle,
  Star,
  Share
} from 'lucide-react-native';

export default function Settings() {
  const insets = useSafeAreaInsets();
  const [notifications, setNotifications] = useState(true);
  const [darkMode, setDarkMode] = useState(true);
  const [soundEffects, setSoundEffects] = useState(true);
  const [autoSave, setAutoSave] = useState(true);

  const SettingItem = ({ icon: Icon, title, subtitle, onPress, rightElement, color = '#00d4ff' }) => (
    <TouchableOpacity
      onPress={onPress}
      style={{
        backgroundColor: '#1a1a1a',
        borderRadius: 12,
        padding: 16,
        marginBottom: 12,
        borderWidth: 1,
        borderColor: '#333',
        flexDirection: 'row',
        alignItems: 'center',
      }}
    >
      <View style={{
        backgroundColor: color + '20',
        borderRadius: 8,
        padding: 8,
        marginRight: 12,
      }}>
        <Icon color={color} size={20} />
      </View>
      <View style={{ flex: 1 }}>
        <Text style={{ color: '#fff', fontSize: 16, fontWeight: '600', marginBottom: 2 }}>
          {title}
        </Text>
        {subtitle && (
          <Text style={{ color: '#888', fontSize: 14 }}>
            {subtitle}
          </Text>
        )}
      </View>
      {rightElement || <ChevronRight color="#666" size={20} />}
    </TouchableOpacity>
  );

  const SectionHeader = ({ title }) => (
    <Text style={{
      color: '#fff',
      fontSize: 18,
      fontWeight: '600',
      marginBottom: 16,
      marginTop: 20,
    }}>
      {title}
    </Text>
  );

  return (
    <View style={{ flex: 1, backgroundColor: '#0a0a0a' }}>
      <StatusBar style="light" />
      
      {/* Header */}
      <View style={{
        paddingTop: insets.top + 20,
        paddingHorizontal: 20,
        paddingBottom: 20,
        backgroundColor: '#111',
        borderBottomWidth: 1,
        borderBottomColor: '#333',
      }}>
        <Text style={{
          color: '#fff',
          fontSize: 28,
          fontWeight: 'bold',
          marginBottom: 8,
        }}>
          Settings
        </Text>
        <Text style={{ color: '#888', fontSize: 14 }}>
          Customize your digital experience
        </Text>
      </View>

      <ScrollView 
        style={{ flex: 1 }} 
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        <View style={{ padding: 20 }}>
          {/* Profile Section */}
          <SectionHeader title="Profile" />
          
          <SettingItem
            icon={User}
            title="Player Profile"
            subtitle="Manage your digital identity"
            color="#00d4ff"
            onPress={() => {}}
          />
          
          <SettingItem
            icon={Star}
            title="Achievements"
            subtitle="View your accomplishments"
            color="#ffaa00"
            onPress={() => {}}
          />

          {/* Game Settings */}
          <SectionHeader title="Game Settings" />
          
          <SettingItem
            icon={Bell}
            title="Notifications"
            subtitle="Alliance updates and world events"
            color="#8b5cf6"
            rightElement={
              <Switch
                value={notifications}
                onValueChange={setNotifications}
                trackColor={{ false: '#333', true: '#8b5cf6' }}
                thumbColor={notifications ? '#fff' : '#666'}
              />
            }
            onPress={() => setNotifications(!notifications)}
          />
          
          <SettingItem
            icon={Volume2}
            title="Sound Effects"
            subtitle="Battle sounds and UI feedback"
            color="#00ff88"
            rightElement={
              <Switch
                value={soundEffects}
                onValueChange={setSoundEffects}
                trackColor={{ false: '#333', true: '#00ff88' }}
                thumbColor={soundEffects ? '#fff' : '#666'}
              />
            }
            onPress={() => setSoundEffects(!soundEffects)}
          />
          
          <SettingItem
            icon={Shield}
            title="Auto-Save"
            subtitle="Automatically save progress"
            color="#ff6b6b"
            rightElement={
              <Switch
                value={autoSave}
                onValueChange={setAutoSave}
                trackColor={{ false: '#333', true: '#ff6b6b' }}
                thumbColor={autoSave ? '#fff' : '#666'}
              />
            }
            onPress={() => setAutoSave(!autoSave)}
          />

          {/* Appearance */}
          <SectionHeader title="Appearance" />
          
          <SettingItem
            icon={Moon}
            title="Dark Mode"
            subtitle="Optimized for digital environments"
            color="#666"
            rightElement={
              <Switch
                value={darkMode}
                onValueChange={setDarkMode}
                trackColor={{ false: '#333', true: '#666' }}
                thumbColor={darkMode ? '#fff' : '#666'}
              />
            }
            onPress={() => setDarkMode(!darkMode)}
          />

          {/* Global Features */}
          <SectionHeader title="Global Features" />
          
          <SettingItem
            icon={Globe}
            title="Language & Region"
            subtitle="English (Global)"
            color="#06b6d4"
            onPress={() => {}}
          />
          
          <SettingItem
            icon={Smartphone}
            title="Smart City Integration"
            subtitle="Connect with Indian tech systems"
            color="#f59e0b"
            onPress={() => {}}
          />

          {/* Support */}
          <SectionHeader title="Support" />
          
          <SettingItem
            icon={HelpCircle}
            title="Help & Tutorial"
            subtitle="Learn advanced strategies"
            color="#8b5cf6"
            onPress={() => {}}
          />
          
          <SettingItem
            icon={Share}
            title="Share with Friends"
            subtitle="Invite others to join your alliance"
            color="#00ff88"
            onPress={() => {}}
          />

          {/* Account */}
          <SectionHeader title="Account" />
          
          <TouchableOpacity style={{
            backgroundColor: '#ff6b6b20',
            borderRadius: 12,
            padding: 16,
            marginBottom: 12,
            borderWidth: 1,
            borderColor: '#ff6b6b40',
            flexDirection: 'row',
            alignItems: 'center',
            justifyContent: 'center',
          }}>
            <LogOut color="#ff6b6b" size={20} style={{ marginRight: 8 }} />
            <Text style={{ color: '#ff6b6b', fontSize: 16, fontWeight: '600' }}>
              Sign Out
            </Text>
          </TouchableOpacity>

          {/* App Info */}
          <View style={{
            backgroundColor: '#1a1a1a',
            borderRadius: 12,
            padding: 16,
            marginTop: 20,
            borderWidth: 1,
            borderColor: '#333',
            alignItems: 'center',
          }}>
            <Text style={{ color: '#888', fontSize: 14, marginBottom: 4 }}>
              Digital Civilization Strategy
            </Text>
            <Text style={{ color: '#666', fontSize: 12, marginBottom: 8 }}>
              Version 2.1.0 (Build 2024.10.26)
            </Text>
            <Text style={{ color: '#00d4ff', fontSize: 12, textAlign: 'center' }}>
              Powered by Next-Gen AI • Real-time Global Competition
            </Text>
          </View>
        </View>
      </ScrollView>
    </View>
  );
}