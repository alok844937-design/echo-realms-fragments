import React, { useState } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Image } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { 
  Users, 
  Shield, 
  Sword, 
  Crown, 
  Star,
  MessageCircle,
  Plus,
  ChevronRight,
  Globe,
  Zap
} from 'lucide-react-native';

export default function Alliances() {
  const insets = useSafeAreaInsets();
  const [activeTab, setActiveTab] = useState('alliances');

  const alliances = [
    {
      id: 1,
      name: 'Digital Guardians',
      members: 847,
      power: 95420,
      status: 'active',
      role: 'Leader',
      color: '#00ff88',
      description: 'Elite coalition focused on world reconstruction',
      avatar: '🛡️'
    },
    {
      id: 2,
      name: 'Quantum Collective',
      members: 1203,
      power: 127850,
      status: 'allied',
      role: 'Member',
      color: '#8b5cf6',
      description: 'Advanced AI research and development',
      avatar: '⚛️'
    },
    {
      id: 3,
      name: 'Neo Architects',
      members: 623,
      power: 78340,
      status: 'pending',
      role: 'Invited',
      color: '#ffaa00',
      description: 'Specialists in smart city construction',
      avatar: '🏗️'
    }
  ];

  const globalPlayers = [
    {
      id: 1,
      name: 'CyberSage_Mumbai',
      level: 47,
      power: 23450,
      status: 'online',
      country: 'India',
      specialization: 'AI Evolution',
      avatar: '🧠'
    },
    {
      id: 2,
      name: 'QuantumKnight_Tokyo',
      level: 52,
      power: 28760,
      status: 'offline',
      country: 'Japan',
      specialization: 'Defense Systems',
      avatar: '⚔️'
    },
    {
      id: 3,
      name: 'NeoBuilder_Berlin',
      level: 39,
      power: 19230,
      status: 'online',
      country: 'Germany',
      specialization: 'Infrastructure',
      avatar: '🏭'
    },
    {
      id: 4,
      name: 'DataMystic_Seoul',
      level: 44,
      power: 21890,
      status: 'online',
      country: 'South Korea',
      specialization: 'Smart Cities',
      avatar: '🌆'
    }
  ];

  const AllianceCard = ({ alliance }) => (
    <TouchableOpacity style={{
      backgroundColor: '#1a1a1a',
      borderRadius: 12,
      padding: 16,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: alliance.color + '40',
    }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
        <View style={{
          backgroundColor: alliance.color + '20',
          borderRadius: 25,
          width: 50,
          height: 50,
          alignItems: 'center',
          justifyContent: 'center',
          marginRight: 12,
        }}>
          <Text style={{ fontSize: 24 }}>{alliance.avatar}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={{ color: '#fff', fontSize: 16, fontWeight: 'bold', marginBottom: 2 }}>
            {alliance.name}
          </Text>
          <Text style={{ color: alliance.color, fontSize: 12, fontWeight: '600' }}>
            {alliance.role}
          </Text>
        </View>
        <View style={{
          backgroundColor: alliance.status === 'active' ? '#00ff88' : 
                          alliance.status === 'allied' ? '#8b5cf6' : '#ffaa00',
          paddingHorizontal: 8,
          paddingVertical: 4,
          borderRadius: 12,
        }}>
          <Text style={{ color: '#000', fontSize: 10, fontWeight: '600', textTransform: 'uppercase' }}>
            {alliance.status}
          </Text>
        </View>
      </View>
      
      <Text style={{ color: '#888', fontSize: 14, marginBottom: 12 }}>
        {alliance.description}
      </Text>
      
      <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
        <View style={{ alignItems: 'center' }}>
          <Users color="#666" size={16} />
          <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600', marginTop: 4 }}>
            {alliance.members.toLocaleString()}
          </Text>
          <Text style={{ color: '#666', fontSize: 10 }}>Members</Text>
        </View>
        <View style={{ alignItems: 'center' }}>
          <Zap color="#666" size={16} />
          <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600', marginTop: 4 }}>
            {alliance.power.toLocaleString()}
          </Text>
          <Text style={{ color: '#666', fontSize: 10 }}>Power</Text>
        </View>
        <TouchableOpacity style={{
          backgroundColor: alliance.color + '20',
          borderRadius: 8,
          paddingHorizontal: 12,
          paddingVertical: 8,
          alignItems: 'center',
          justifyContent: 'center',
        }}>
          <MessageCircle color={alliance.color} size={16} />
        </TouchableOpacity>
      </View>
    </TouchableOpacity>
  );

  const PlayerCard = ({ player }) => (
    <TouchableOpacity style={{
      backgroundColor: '#1a1a1a',
      borderRadius: 12,
      padding: 16,
      marginBottom: 12,
      borderWidth: 1,
      borderColor: '#333',
      flexDirection: 'row',
      alignItems: 'center',
    }}>
      <View style={{
        backgroundColor: player.status === 'online' ? '#00ff88' : '#666',
        borderRadius: 25,
        width: 50,
        height: 50,
        alignItems: 'center',
        justifyContent: 'center',
        marginRight: 12,
      }}>
        <Text style={{ fontSize: 24 }}>{player.avatar}</Text>
      </View>
      
      <View style={{ flex: 1 }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 2 }}>
          <Text style={{ color: '#fff', fontSize: 16, fontWeight: 'bold', marginRight: 8 }}>
            {player.name}
          </Text>
          <View style={{
            backgroundColor: player.status === 'online' ? '#00ff88' : '#666',
            width: 8,
            height: 8,
            borderRadius: 4,
          }} />
        </View>
        <Text style={{ color: '#888', fontSize: 12, marginBottom: 4 }}>
          Level {player.level} • {player.country}
        </Text>
        <Text style={{ color: '#00d4ff', fontSize: 12 }}>
          {player.specialization}
        </Text>
      </View>
      
      <View style={{ alignItems: 'flex-end' }}>
        <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600' }}>
          {player.power.toLocaleString()}
        </Text>
        <Text style={{ color: '#666', fontSize: 10 }}>Power</Text>
      </View>
      
      <ChevronRight color="#666" size={20} style={{ marginLeft: 8 }} />
    </TouchableOpacity>
  );

  return (
    <View style={{ flex: 1, backgroundColor: '#0a0a0a' }}>
      <StatusBar style="light" />
      
      {/* Header */}
      <View style={{
        paddingTop: insets.top + 20,
        paddingHorizontal: 20,
        paddingBottom: 20,
        backgroundColor: '#111',
        borderBottomWidth: 1,
        borderBottomColor: '#333',
      }}>
        <Text style={{
          color: '#fff',
          fontSize: 28,
          fontWeight: 'bold',
          marginBottom: 8,
        }}>
          Tactical Network
        </Text>
        <Text style={{ color: '#888', fontSize: 14 }}>
          Build alliances and compete globally
        </Text>
      </View>

      {/* Tab Navigation */}
      <View style={{
        flexDirection: 'row',
        backgroundColor: '#111',
        paddingHorizontal: 20,
        paddingVertical: 12,
        borderBottomWidth: 1,
        borderBottomColor: '#333',
      }}>
        <TouchableOpacity
          onPress={() => setActiveTab('alliances')}
          style={{
            flex: 1,
            alignItems: 'center',
            paddingVertical: 8,
            borderBottomWidth: 2,
            borderBottomColor: activeTab === 'alliances' ? '#00d4ff' : 'transparent',
          }}
        >
          <Text style={{
            color: activeTab === 'alliances' ? '#00d4ff' : '#666',
            fontSize: 16,
            fontWeight: '600',
          }}>
            My Alliances
          </Text>
        </TouchableOpacity>
        <TouchableOpacity
          onPress={() => setActiveTab('global')}
          style={{
            flex: 1,
            alignItems: 'center',
            paddingVertical: 8,
            borderBottomWidth: 2,
            borderBottomColor: activeTab === 'global' ? '#00d4ff' : 'transparent',
          }}
        >
          <Text style={{
            color: activeTab === 'global' ? '#00d4ff' : '#666',
            fontSize: 16,
            fontWeight: '600',
          }}>
            Global Players
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView 
        style={{ flex: 1 }} 
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {activeTab === 'alliances' ? (
          <View style={{ padding: 20 }}>
            {/* Create Alliance Button */}
            <TouchableOpacity style={{
              backgroundColor: '#00d4ff20',
              borderRadius: 12,
              padding: 16,
              marginBottom: 20,
              borderWidth: 1,
              borderColor: '#00d4ff',
              flexDirection: 'row',
              alignItems: 'center',
              justifyContent: 'center',
            }}>
              <Plus color="#00d4ff" size={20} style={{ marginRight: 8 }} />
              <Text style={{ color: '#00d4ff', fontSize: 16, fontWeight: '600' }}>
                Create New Alliance
              </Text>
            </TouchableOpacity>

            {/* Alliance List */}
            {alliances.map((alliance) => (
              <AllianceCard key={alliance.id} alliance={alliance} />
            ))}
          </View>
        ) : (
          <View style={{ padding: 20 }}>
            {/* Global Competition Stats */}
            <View style={{
              backgroundColor: '#1a1a1a',
              borderRadius: 12,
              padding: 16,
              marginBottom: 20,
              borderWidth: 1,
              borderColor: '#333',
            }}>
              <Text style={{ color: '#fff', fontSize: 16, fontWeight: '600', marginBottom: 12 }}>
                Global Competition
              </Text>
              <View style={{ flexDirection: 'row', justifyContent: 'space-between' }}>
                <View style={{ alignItems: 'center' }}>
                  <Globe color="#00d4ff" size={20} />
                  <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600', marginTop: 4 }}>
                    2.4M
                  </Text>
                  <Text style={{ color: '#666', fontSize: 10 }}>Active Players</Text>
                </View>
                <View style={{ alignItems: 'center' }}>
                  <Crown color="#ffaa00" size={20} />
                  <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600', marginTop: 4 }}>
                    #247
                  </Text>
                  <Text style={{ color: '#666', fontSize: 10 }}>Your Rank</Text>
                </View>
                <View style={{ alignItems: 'center' }}>
                  <Star color="#8b5cf6" size={20} />
                  <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600', marginTop: 4 }}>
                    8.7k
                  </Text>
                  <Text style={{ color: '#666', fontSize: 10 }}>Rating</Text>
                </View>
              </View>
            </View>

            {/* Player List */}
            {globalPlayers.map((player) => (
              <PlayerCard key={player.id} player={player} />
            ))}
          </View>
        )}
      </ScrollView>
    </View>
  );
}