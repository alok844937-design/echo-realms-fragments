import React, { useState, useRef } from 'react';
import { View, Text, ScrollView, TouchableOpacity, Animated, Dimensions } from 'react-native';
import { StatusBar } from 'expo-status-bar';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { 
  Map, 
  Zap, 
  Shield, 
  AlertTriangle, 
  CheckCircle,
  Clock,
  Layers,
  Target
} from 'lucide-react-native';

const { width } = Dimensions.get('window');

export default function WorldMap() {
  const insets = useSafeAreaInsets();
  const [selectedSector, setSelectedSector] = useState(null);
  const scaleAnim = useRef(new Animated.Value(1)).current;

  const sectors = [
    { id: 1, name: 'Neo Mumbai', status: 'stable', progress: 85, x: 120, y: 180, color: '#00ff88' },
    { id: 2, name: 'Digital Delhi', status: 'reconstructing', progress: 45, x: 200, y: 120, color: '#ffaa00' },
    { id: 3, name: 'Cyber Chennai', status: 'damaged', progress: 15, x: 160, y: 280, color: '#ff6b6b' },
    { id: 4, name: 'Tech Bangalore', status: 'stable', progress: 92, x: 140, y: 240, color: '#00ff88' },
    { id: 5, name: 'Smart Hyderabad', status: 'evolving', progress: 67, x: 180, y: 200, color: '#8b5cf6' },
    { id: 6, name: 'Quantum Kolkata', status: 'damaged', progress: 8, x: 240, y: 160, color: '#ff6b6b' },
  ];

  const getStatusIcon = (status) => {
    switch (status) {
      case 'stable': return CheckCircle;
      case 'reconstructing': return Clock;
      case 'evolving': return Zap;
      case 'damaged': return AlertTriangle;
      default: return Target;
    }
  };

  const handleSectorPress = (sector) => {
    setSelectedSector(sector);
    Animated.sequence([
      Animated.timing(scaleAnim, {
        toValue: 1.1,
        duration: 150,
        useNativeDriver: true,
      }),
      Animated.timing(scaleAnim, {
        toValue: 1,
        duration: 150,
        useNativeDriver: true,
      }),
    ]).start();
  };

  const SectorNode = ({ sector }) => {
    const StatusIcon = getStatusIcon(sector.status);
    const isSelected = selectedSector?.id === sector.id;
    
    return (
      <TouchableOpacity
        onPress={() => handleSectorPress(sector)}
        style={{
          position: 'absolute',
          left: sector.x,
          top: sector.y,
          alignItems: 'center',
        }}
      >
        <Animated.View style={{
          transform: [{ scale: isSelected ? scaleAnim : 1 }],
          backgroundColor: sector.color + '30',
          borderRadius: 25,
          padding: 12,
          borderWidth: 2,
          borderColor: sector.color,
          shadowColor: sector.color,
          shadowOffset: { width: 0, height: 0 },
          shadowOpacity: 0.8,
          shadowRadius: 10,
          elevation: 10,
        }}>
          <StatusIcon color={sector.color} size={20} />
        </Animated.View>
        <Text style={{
          color: '#fff',
          fontSize: 10,
          marginTop: 4,
          textAlign: 'center',
          fontWeight: '600',
        }}>
          {sector.name}
        </Text>
        <Text style={{
          color: sector.color,
          fontSize: 8,
          textAlign: 'center',
        }}>
          {sector.progress}%
        </Text>
      </TouchableOpacity>
    );
  };

  return (
    <View style={{ flex: 1, backgroundColor: '#0a0a0a' }}>
      <StatusBar style="light" />
      
      {/* Header */}
      <View style={{
        paddingTop: insets.top + 20,
        paddingHorizontal: 20,
        paddingBottom: 20,
        backgroundColor: '#111',
        borderBottomWidth: 1,
        borderBottomColor: '#333',
      }}>
        <Text style={{
          color: '#fff',
          fontSize: 28,
          fontWeight: 'bold',
          marginBottom: 8,
        }}>
          Digital World Map
        </Text>
        <Text style={{ color: '#888', fontSize: 14 }}>
          Fragmented territories awaiting reconstruction
        </Text>
      </View>

      <ScrollView 
        style={{ flex: 1 }} 
        contentContainerStyle={{ paddingBottom: insets.bottom + 20 }}
        showsVerticalScrollIndicator={false}
      >
        {/* World Map Visualization */}
        <View style={{ padding: 20 }}>
          <View style={{
            backgroundColor: '#1a1a1a',
            borderRadius: 16,
            padding: 20,
            borderWidth: 1,
            borderColor: '#333',
            height: 350,
            position: 'relative',
            overflow: 'hidden',
          }}>
            {/* Grid Background */}
            <View style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              opacity: 0.1,
            }}>
              {Array.from({ length: 20 }).map((_, i) => (
                <View key={`h-${i}`} style={{
                  position: 'absolute',
                  left: 0,
                  right: 0,
                  top: i * 17.5,
                  height: 1,
                  backgroundColor: '#00d4ff',
                }} />
              ))}
              {Array.from({ length: 15 }).map((_, i) => (
                <View key={`v-${i}`} style={{
                  position: 'absolute',
                  top: 0,
                  bottom: 0,
                  left: i * 20,
                  width: 1,
                  backgroundColor: '#00d4ff',
                }} />
              ))}
            </View>

            {/* Sector Nodes */}
            {sectors.map((sector) => (
              <SectorNode key={sector.id} sector={sector} />
            ))}

            {/* Connection Lines */}
            <View style={{
              position: 'absolute',
              top: 0,
              left: 0,
              right: 0,
              bottom: 0,
              opacity: 0.3,
            }}>
              {/* Add connection lines between sectors here */}
            </View>
          </View>
        </View>

        {/* Sector Details */}
        {selectedSector && (
          <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
            <View style={{
              backgroundColor: '#1a1a1a',
              borderRadius: 12,
              padding: 16,
              borderWidth: 1,
              borderColor: selectedSector.color,
            }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 12 }}>
                <View style={{
                  backgroundColor: selectedSector.color + '20',
                  borderRadius: 8,
                  padding: 8,
                  marginRight: 12,
                }}>
                  {React.createElement(getStatusIcon(selectedSector.status), {
                    color: selectedSector.color,
                    size: 24
                  })}
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ color: '#fff', fontSize: 18, fontWeight: 'bold' }}>
                    {selectedSector.name}
                  </Text>
                  <Text style={{ color: selectedSector.color, fontSize: 14, textTransform: 'capitalize' }}>
                    {selectedSector.status}
                  </Text>
                </View>
              </View>
              
              <View style={{ marginBottom: 12 }}>
                <View style={{ flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8 }}>
                  <Text style={{ color: '#888', fontSize: 14 }}>Reconstruction Progress</Text>
                  <Text style={{ color: selectedSector.color, fontSize: 14, fontWeight: '600' }}>
                    {selectedSector.progress}%
                  </Text>
                </View>
                <View style={{
                  backgroundColor: '#333',
                  height: 8,
                  borderRadius: 4,
                  overflow: 'hidden',
                }}>
                  <View style={{
                    backgroundColor: selectedSector.color,
                    height: '100%',
                    width: `${selectedSector.progress}%`,
                    borderRadius: 4,
                  }} />
                </View>
              </View>

              <TouchableOpacity style={{
                backgroundColor: selectedSector.color + '20',
                borderRadius: 8,
                padding: 12,
                borderWidth: 1,
                borderColor: selectedSector.color,
                alignItems: 'center',
              }}>
                <Text style={{ color: selectedSector.color, fontSize: 16, fontWeight: '600' }}>
                  Deploy Resources
                </Text>
              </TouchableOpacity>
            </View>
          </View>
        )}

        {/* Legend */}
        <View style={{ paddingHorizontal: 20 }}>
          <Text style={{ color: '#fff', fontSize: 18, fontWeight: '600', marginBottom: 16 }}>
            Sector Status Legend
          </Text>
          <View style={{
            backgroundColor: '#1a1a1a',
            borderRadius: 12,
            padding: 16,
            borderWidth: 1,
            borderColor: '#333',
          }}>
            {[
              { status: 'stable', color: '#00ff88', description: 'Fully operational and secure' },
              { status: 'evolving', color: '#8b5cf6', description: 'AI systems actively upgrading' },
              { status: 'reconstructing', color: '#ffaa00', description: 'Under active repair' },
              { status: 'damaged', color: '#ff6b6b', description: 'Requires immediate attention' },
            ].map((item) => {
              const StatusIcon = getStatusIcon(item.status);
              return (
                <View key={item.status} style={{
                  flexDirection: 'row',
                  alignItems: 'center',
                  marginBottom: 12,
                }}>
                  <StatusIcon color={item.color} size={20} style={{ marginRight: 12 }} />
                  <View style={{ flex: 1 }}>
                    <Text style={{ color: '#fff', fontSize: 14, fontWeight: '600', textTransform: 'capitalize' }}>
                      {item.status}
                    </Text>
                    <Text style={{ color: '#888', fontSize: 12 }}>
                      {item.description}
                    </Text>
                  </View>
                </View>
              );
            })}
          </View>
        </View>
      </ScrollView>
    </View>
  );
}