import { Tabs } from 'expo-router';
import { Home, Globe, Users, Settings, Zap } from 'lucide-react-native';

export default function TabLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarStyle: {
          backgroundColor: '#0a0a0a',
          borderTopWidth: 1,
          borderColor: '#1a1a1a',
          paddingTop: 4,
        },
        tabBarActiveTintColor: '#00d4ff',
        tabBarInactiveTintColor: '#666666',
        tabBarLabelStyle: {
          fontSize: 12,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: 'Command',
          tabBarIcon: ({ color, size }) => (
            <Home color={color} size={24} />
          ),
        }}
      />
      <Tabs.Screen
        name="world"
        options={{
          title: 'World',
          tabBarIcon: ({ color, size }) => (
            <Globe color={color} size={24} />
          ),
        }}
      />
      <Tabs.Screen
        name="alliances"
        options={{
          title: 'Alliances',
          tabBarIcon: ({ color, size }) => (
            <Users color={color} size={24} />
          ),
        }}
      />
      <Tabs.Screen
        name="evolution"
        options={{
          title: 'Evolution',
          tabBarIcon: ({ color, size }) => (
            <Zap color={color} size={24} />
          ),
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: 'Settings',
          tabBarIcon: ({ color, size }) => (
            <Settings color={color} size={24} />
          ),
        }}
      />
    </Tabs>
  );
}